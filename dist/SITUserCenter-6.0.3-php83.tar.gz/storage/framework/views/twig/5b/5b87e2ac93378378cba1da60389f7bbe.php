<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user.widgets.profile.password */
class __TwigTemplate_876cac25bcb50b556106f02258afa6dc extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<form class=\"card card-warning\" method=\"post\" id=\"change-password\">
  <div class=\"card-header\">
    <h3 class=\"card-title\">
      ";
        // line 4
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.profile.password.title"), "html", null, true);
        yield "
    </h3>
  </div>
  <div class=\"card-body\">
    <div class=\"form-group\">
      <label>";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.profile.password.old"), "html", null, true);
        yield "</label>
      <input type=\"password\" class=\"form-control\" name=\"oldPassword\"
        required autocomplete=\"current-password\">
    </div>

    <div class=\"form-group\">
      <label>";
        // line 15
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.profile.password.new"), "html", null, true);
        yield "</label>
      <input type=\"password\" class=\"form-control\" name=\"newPassword\" required
        minlength=\"8\" maxlength=\"32\" autocomplete=\"new-password\">
    </div>

    <div class=\"form-group\">
      <label>";
        // line 21
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.profile.password.confirm"), "html", null, true);
        yield "</label>
      <input type=\"password\" class=\"form-control\" name=\"confirm\" required
        minlength=\"8\" maxlength=\"32\" autocomplete=\"new-password\">
    </div>
  </div>
  <div class=\"card-footer\">
    <button class=\"btn btn-primary\" type=\"submit\">
      ";
        // line 28
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.profile.password.button"), "html", null, true);
        yield "
    </button>
  </div>
</form>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user.widgets.profile.password";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  84 => 28,  74 => 21,  65 => 15,  56 => 9,  48 => 4,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user.widgets.profile.password", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/user/widgets/profile/password.twig");
    }
}
