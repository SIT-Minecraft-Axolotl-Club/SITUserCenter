<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* shared.header */
class __TwigTemplate_d7dc3cec0cb5e65458d81d127534466a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<nav class=\"main-header navbar navbar-expand navbar-";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["navbar_color"] ?? null), "html", null, true);
        yield " navbar-";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color_mode"] ?? null), "html", null, true);
        yield "\">
  <ul class=\"navbar-nav\">
    <li class=\"nav-item\">
      <a class=\"nav-link\" data-widget=\"pushmenu\" href=\"#\">
        <i class=\"fas fa-bars\"></i>
      </a>
    </li>
  </ul>

  <ul class=\"navbar-nav ml-auto\">
    ";
        // line 11
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.dark-mode");
        yield "
    ";
        // line 12
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.notifications");
        yield "
    ";
        // line 13
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.languages");
        yield "
    ";
        // line 14
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.user-menu");
        yield "
  </ul>
</nav>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "shared.header";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  71 => 14,  67 => 13,  63 => 12,  59 => 11,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "shared.header", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/shared/header.twig");
    }
}
