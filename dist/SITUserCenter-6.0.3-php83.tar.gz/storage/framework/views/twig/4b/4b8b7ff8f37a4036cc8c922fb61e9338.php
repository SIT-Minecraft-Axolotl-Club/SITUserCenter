<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* admin.widgets.dashboard.usage */
class __TwigTemplate_6f0c001f2cd796f261bf4683d5cb91f9 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<div class=\"row\">
  <div class=\"col-md-6\">
    <div class=\"small-box bg-info\">
      <div class=\"inner\">
        <h3 class=\"stats\">";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["sum"] ?? null), "users", [], "any", false, false, false, 5), "html", null, true);
        yield "</h3>
        <p>";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.index.total-users"), "html", null, true);
        yield "</p>
      </div>
      <div class=\"icon\"><i class=\"fas fa-users\"></i></div>
      <a href=\"";
        // line 9
        yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("admin/users");
        yield "\" class=\"small-box-footer\">
        ";
        // line 10
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.user-manage"), "html", null, true);
        yield "&nbsp;
        <i class=\"fa fa-arrow-circle-right\"></i>
      </a>
    </div>
  </div>

  <div class=\"col-md-6\">
    <div class=\"small-box bg-green\">
      <div class=\"inner\">
        <h3 class=\"stats\">";
        // line 19
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["sum"] ?? null), "players", [], "any", false, false, false, 19), "html", null, true);
        yield "</h3>
        <p>";
        // line 20
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.index.total-players"), "html", null, true);
        yield "</p>
      </div>
      <div class=\"icon\"><i class=\"fas fa-gamepad\"></i></div>
      <a href=\"";
        // line 23
        yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("admin/players");
        yield "\" class=\"small-box-footer\">
        ";
        // line 24
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.player-manage"), "html", null, true);
        yield "&nbsp;
        <i class=\"fa fa-arrow-circle-right\"></i>
      </a>
    </div>
  </div>
</div>

<div class=\"row\">
  <div class=\"col-md-6\">
    <div class=\"small-box bg-purple\">
      <div class=\"inner\">
        <h3 class=\"stats\">";
        // line 35
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["sum"] ?? null), "textures", [], "any", false, false, false, 35), "html", null, true);
        yield "</h3>
        <p>";
        // line 36
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.index.total-textures"), "html", null, true);
        yield "</p>
      </div>
      <div class=\"icon\"><i class=\"fas fa-file\"></i></div>
    </div>
  </div>

  <div class=\"col-md-6\">
    <div class=\"small-box bg-yellow\">
      <div class=\"inner\">
        ";
        // line 45
        if ((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["sum"] ?? null), "storage", [], "any", false, false, false, 45) > 1024)) {
            // line 46
            yield "          <h3 class=\"stats\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::round((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["sum"] ?? null), "storage", [], "any", false, false, false, 46) / 1024), 1), "html", null, true);
            yield "MB</h3>
        ";
        } else {
            // line 48
            yield "          <h3 class=\"stats\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["sum"] ?? null), "storage", [], "any", false, false, false, 48), "html", null, true);
            yield "KB</h3>
        ";
        }
        // line 50
        yield "        <p>";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.index.disk-usage"), "html", null, true);
        yield "</p>
      </div>
      <div class=\"icon\"><i class=\"fas fa-hdd\"></i></div>
    </div>
  </div>
</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "admin.widgets.dashboard.usage";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  133 => 50,  127 => 48,  121 => 46,  119 => 45,  107 => 36,  103 => 35,  89 => 24,  85 => 23,  79 => 20,  75 => 19,  63 => 10,  59 => 9,  53 => 6,  49 => 5,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "admin.widgets.dashboard.usage", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/widgets/dashboard/usage.twig");
    }
}
