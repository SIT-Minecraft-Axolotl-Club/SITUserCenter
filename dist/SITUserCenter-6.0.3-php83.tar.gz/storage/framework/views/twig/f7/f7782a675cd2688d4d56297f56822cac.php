<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user.widgets.dashboard.announcement */
class __TwigTemplate_4475f2a52bf398a467e4a5fb7bed06bc extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<div class=\"card card-primary card-outline\">
  <div class=\"card-header\">
    <h3 class=\"card-title\">";
        // line 3
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.announcement"), "html", null, true);
        yield "</h3>
    ";
        // line 4
        if (TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $this->env->getFunction('auth_user')->getCallable()(), "admin", [], "any", false, false, false, 4)) {
            // line 5
            yield "      &nbsp;
      <a href=\"";
            // line 6
            yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("/admin/options");
            yield "\">
        <i class=\"fas fa-edit\"></i>
      </a>
    ";
        }
        // line 10
        yield "  </div>
  <div class=\"card-body\">
    ";
        // line 12
        yield ($context["announcement"] ?? null);
        yield "
  </div>
</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user.widgets.dashboard.announcement";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  67 => 12,  63 => 10,  56 => 6,  53 => 5,  51 => 4,  47 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user.widgets.dashboard.announcement", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/user/widgets/dashboard/announcement.twig");
    }
}
