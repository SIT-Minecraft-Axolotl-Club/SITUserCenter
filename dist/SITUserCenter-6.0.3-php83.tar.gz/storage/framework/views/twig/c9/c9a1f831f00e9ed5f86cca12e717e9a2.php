<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* shared.head */
class __TwigTemplate_58c0e7315858ef5bbb9ed10101b504ab extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<meta charset=\"utf-8\">
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\">
<meta name=\"csrf-token\" content=\"";
        // line 4
        yield $this->env->getFunction('csrf_token')->getCallable()();
        yield "\">
<meta name=\"theme-color\" content=\"";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["theme_color"] ?? null), "html", null, true);
        yield "\">
<meta name=\"keywords\" content=\"";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["seo"] ?? null), "keywords", [], "any", false, false, false, 6), "html", null, true);
        yield "\">
<meta name=\"description\" content=\"";
        // line 7
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["seo"] ?? null), "description", [], "any", false, false, false, 7), "html", null, true);
        yield "\">
";
        // line 8
        yield Twig\Extension\CoreExtension::striptags(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["seo"] ?? null), "extra", [], "any", false, false, false, 8), "<meta>");
        yield "
";
        // line 9
        if (($context["custom_cdn_host"] ?? null)) {
            // line 10
            yield "  <link rel=\"preconnect\" href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["custom_cdn_host"] ?? null), "html", null, true);
            yield "\" id=\"cdn-host\" crossorigin>
";
        }
        // line 12
        yield "<script>window.blessing = ";
        yield json_encode(($context["blessing"] ?? null));
        yield "</script>
";
        // line 13
        yield Twig\Extension\CoreExtension::include($this->env, $context, "assets.style", [], true, true);
        yield "
";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["links"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
            // line 15
            yield "  <link";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable($context["link"]);
            foreach ($context['_seq'] as $context["attribute"] => $context["value"]) {
                yield " ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["attribute"], "html", null, true);
                yield "=\"";
                yield $context["value"];
                yield "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['attribute'], $context['value'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            yield ">
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['link'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        yield "<link rel=\"shortcut icon\" href=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["favicon"] ?? null), "html", null, true);
        yield "\">
<link rel=\"icon\" type=\"image/png\" href=\"";
        // line 18
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["favicon"] ?? null), "html", null, true);
        yield "\" sizes=\"192x192\">
<link rel=\"apple-touch-icon\" href=\"";
        // line 19
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["favicon"] ?? null), "html", null, true);
        yield "\" sizes=\"180x180\">
";
        // line 20
        if (($context["inline_css"] ?? null)) {
            // line 21
            yield "  <style>";
            yield Twig\Extension\CoreExtension::striptags(($context["inline_css"] ?? null));
            yield "</style>
";
        }
        // line 23
        yield Twig\Extension\CoreExtension::join(($context["extra_head"] ?? null), "
");
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "shared.head";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  130 => 23,  124 => 21,  122 => 20,  118 => 19,  114 => 18,  109 => 17,  89 => 15,  85 => 14,  81 => 13,  76 => 12,  70 => 10,  68 => 9,  64 => 8,  60 => 7,  56 => 6,  52 => 5,  48 => 4,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "shared.head", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/shared/head.twig");
    }
}
