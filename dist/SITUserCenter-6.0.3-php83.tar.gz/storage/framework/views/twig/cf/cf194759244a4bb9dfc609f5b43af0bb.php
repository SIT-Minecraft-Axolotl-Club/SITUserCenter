<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\Users\Administrator\Desktop\blessingskin\SITUserCenter-clean\resources\views/admin/customize.twig */
class __TwigTemplate_c4f7eeed4ac187cadbccc5079bad3a0f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
            'before_foot' => [$this, 'block_before_foot'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "admin.base";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        $this->parent = $this->loadTemplate("admin.base", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/customize.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.customize"), "html", null, true);
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "  <div class=\"row\">
    <div class=\"col-md-3\">
      <form class=\"card box-primary\" method=\"post\" action=\"";
        // line 8
        yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("/admin/customize?action=color");
        yield "\">
        ";
        // line 9
        yield csrf_field();
        yield "
        <div class=\"card-header\">
          <h3 class=\"card-title\">
            ";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.customize.change-color.title"), "html", null, true);
        yield "
          </h3>
        </div>
        <div class=\"card-body\">
          <div id=\"navbar-color-picker\">
            <p>";
        // line 17
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.customize.colors.navbar"), "html", null, true);
        yield "</p>
            <div>
              ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["colors"] ?? null), "navbar", [], "any", false, false, false, 19));
        foreach ($context['_seq'] as $context["_key"] => $context["color"]) {
            // line 20
            yield "                <label>
                  <input type=\"radio\" class=\"d-none\" name=\"navbar\" value=\"";
            // line 21
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["color"], "html", null, true);
            yield "\">
                  <div class=\"btn-color bg-";
            // line 22
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["color"], "html", null, true);
            yield " display-inline-block
                    rounded-pill mr-2 mb-1 elevation-2\"
                  ></div>
                </label>
              ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['color'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        yield "            </div>
          </div>
          <div id=\"sidebar-dark-picker\">
            <p>";
        // line 30
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.customize.colors.sidebar.dark"), "html", null, true);
        yield "</p>
            <div>
              ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["colors"] ?? null), "sidebar", [], "any", false, false, false, 32));
        foreach ($context['_seq'] as $context["_key"] => $context["color"]) {
            // line 33
            yield "                <label>
                  <input type=\"radio\" class=\"d-none\" name=\"sidebar\" value=\"dark-";
            // line 34
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["color"], "html", null, true);
            yield "\">
                  <div class=\"btn-color bg-";
            // line 35
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["color"], "html", null, true);
            yield " display-inline-block
                    rounded-pill mr-2 mb-1 elevation-2\"
                  ></div>
                </label>
              ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['color'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        yield "            </div>
          </div>
          <div id=\"sidebar-light-picker\">
            <p>";
        // line 43
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.customize.colors.sidebar.light"), "html", null, true);
        yield "</p>
            <div>
              ";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["colors"] ?? null), "sidebar", [], "any", false, false, false, 45));
        foreach ($context['_seq'] as $context["_key"] => $context["color"]) {
            // line 46
            yield "                <label>
                  <input type=\"radio\" class=\"d-none\" name=\"sidebar\" value=\"light-";
            // line 47
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["color"], "html", null, true);
            yield "\">
                  <div class=\"btn-color bg-";
            // line 48
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["color"], "html", null, true);
            yield " display-inline-block
                    rounded-pill mr-2 mb-1 elevation-2\"
                  ></div>
                </label>
              ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['color'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        yield "            </div>
          </div>
        </div>
        <div class=\"card-footer\">
          <input
            type=\"submit\"
            class=\"btn btn-primary\"
            value=\"";
        // line 60
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.submit"), "html", null, true);
        yield "\"
            name=\"submit_color\"
          >
        </div>
      </form>
    </div>
    <div class=\"col-md-9\">
      ";
        // line 67
        yield TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["forms"] ?? null), "homepage", [], "any", false, false, false, 67);
        yield "
      ";
        // line 68
        yield TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["forms"] ?? null), "custom_js_css", [], "any", false, false, false, 68);
        yield "
    </div>
  </div>
";
        yield from [];
    }

    // line 73
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_before_foot(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 74
        yield "  <script id=\"blessing-extra\" type=\"application/json\">
    ";
        // line 75
        yield json_encode(($context["extra"] ?? null));
        yield "
  </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/customize.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  227 => 75,  224 => 74,  217 => 73,  208 => 68,  204 => 67,  194 => 60,  185 => 53,  174 => 48,  170 => 47,  167 => 46,  163 => 45,  158 => 43,  153 => 40,  142 => 35,  138 => 34,  135 => 33,  131 => 32,  126 => 30,  121 => 27,  110 => 22,  106 => 21,  103 => 20,  99 => 19,  94 => 17,  86 => 12,  80 => 9,  76 => 8,  72 => 6,  65 => 5,  54 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/customize.twig", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/customize.twig");
    }
}
