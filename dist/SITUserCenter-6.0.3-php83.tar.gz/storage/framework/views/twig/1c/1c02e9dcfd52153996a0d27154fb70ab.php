<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user.widgets.profile.email */
class __TwigTemplate_4f915efed2056c901a13983df86da573 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<form class=\"card card-warning\" method=\"post\" id=\"change-email\">
  <div class=\"card-header\">
    <h3 class=\"card-title\">";
        // line 3
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.profile.email.title"), "html", null, true);
        yield "</h3>
  </div>
  <div class=\"card-body\">
    <div class=\"form-group\">
      <label class=\"text-muted small\" style=\"font-weight: 500;\">当前邮箱</label>
      <div style=\"border-bottom: 2px solid #e0e0e0; padding: 8px 0; font-size: 1.1rem; display: flex; align-items: center; justify-content: space-between;\">
        <span style=\"color: #333; font-weight: 500;\">";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["user"] ?? null), "email", [], "any", false, false, false, 9), "html", null, true);
        yield "</span>
      </div>
      <input type=\"hidden\" name=\"email\" value=\"";
        // line 11
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["user"] ?? null), "email", [], "any", false, false, false, 11), "html", null, true);
        yield "\">
      <small class=\"text-muted\" style=\"margin-top: 6px; display: block;\">如需修改请联系管理员</small>
    </div>
  </div>
</form>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user.widgets.profile.email";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  61 => 11,  56 => 9,  47 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user.widgets.profile.email", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/user/widgets/profile/email.twig");
    }
}
