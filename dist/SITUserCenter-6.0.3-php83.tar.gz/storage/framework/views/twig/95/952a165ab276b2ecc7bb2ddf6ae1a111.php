<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* shared.copyright */
class __TwigTemplate_611304fd1a0abd0d4e92fcc2c1a18184 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        $context["repo"] = "https://github.com/bs-community/blessing-skin-server";
        // line 2
        yield "
<!-- YOU CAN NOT MODIFIY THE COPYRIGHT TEXT W/O PERMISSION -->
<div id=\"copyright-text\" class=\"float-right d-none d-sm-inline\">
  ";
        // line 5
        if ((($context["copyright"] ?? null) == 0)) {
            // line 6
            yield "    Powered with ❤ by <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["repo"] ?? null), "html", null, true);
            yield "\" target=\"_blank\">Blessing Skin Server</a>.
  ";
        } elseif ((        // line 7
($context["copyright"] ?? null) == 1)) {
            // line 8
            yield "    Powered by <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["repo"] ?? null), "html", null, true);
            yield "\" target=\"_blank\">Blessing Skin Server</a>.
  ";
        } elseif ((        // line 9
($context["copyright"] ?? null) == 2)) {
            // line 10
            yield "    Proudly powered by <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["repo"] ?? null), "html", null, true);
            yield "\" target=\"_blank\">Blessing Skin Server</a>.
  ";
        } elseif ((        // line 11
($context["copyright"] ?? null) == 3)) {
            // line 12
            yield "    由 <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["repo"] ?? null), "html", null, true);
            yield "\" target=\"_blank\">Blessing Skin Server</a> 强力驱动。
  ";
        } elseif ((        // line 13
($context["copyright"] ?? null) == 4)) {
            // line 14
            yield "    采用 <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["repo"] ?? null), "html", null, true);
            yield "\" target=\"_blank\">Blessing Skin Server</a> 搭建。
  ";
        } elseif ((        // line 15
($context["copyright"] ?? null) == 5)) {
            // line 16
            yield "    使用 <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["repo"] ?? null), "html", null, true);
            yield "\" target=\"_blank\">Blessing Skin Server</a> 稳定运行。
  ";
        } else {
            // line 18
            yield "    自豪地采用 <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["repo"] ?? null), "html", null, true);
            yield "\" target=\"_blank\">Blessing Skin Server</a>。
  ";
        }
        // line 20
        yield "</div>

";
        // line 22
        $context["rules"] = ["{site_name}" => ($context["site_name"] ?? null), "{site_url}" => ($context["site_url"] ?? null)];
        // line 23
        yield Twig\Extension\CoreExtension::replace(($context["custom_copyright"] ?? null), ($context["rules"] ?? null));
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "shared.copyright";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  105 => 23,  103 => 22,  99 => 20,  93 => 18,  87 => 16,  85 => 15,  80 => 14,  78 => 13,  73 => 12,  71 => 11,  66 => 10,  64 => 9,  59 => 8,  57 => 7,  52 => 6,  50 => 5,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "shared.copyright", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/shared/copyright.twig");
    }
}
