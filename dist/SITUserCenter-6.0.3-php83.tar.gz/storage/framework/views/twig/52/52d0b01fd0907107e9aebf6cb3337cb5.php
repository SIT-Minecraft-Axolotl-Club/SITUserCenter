<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\Users\Administrator\Desktop\blessingskin\SITUserCenter-clean\resources\views/user/report.twig */
class __TwigTemplate_4cae94f5c9e6aba89b5e105e79f4dd70 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "user.base";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        $this->parent = $this->loadTemplate("user.base", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/user/report.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.my-reports"), "html", null, true);
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "  <div class=\"card\">
    <div class=\"card-body p-0\">
      <table class=\"table table-striped\">
        <thead>
          <tr>
            <th>";
        // line 11
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("front-end.report.tid"), "html", null, true);
        yield "</th>
            <th>";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("front-end.report.reason"), "html", null, true);
        yield "</th>
            <th>";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("front-end.report.status-title"), "html", null, true);
        yield "</th>
            <th>";
        // line 14
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("front-end.report.time"), "html", null, true);
        yield "</th>
          </tr>
        </thead>
        <tbody>
          ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["reports"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["report"]) {
            // line 19
            yield "            <tr>
              <td>
                ";
            // line 21
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["report"], "tid", [], "any", false, false, false, 21), "html", null, true);
            yield "&nbsp;
                <a href=\"";
            // line 22
            yield $this->env->getFunction('route')->getCallable()("skinlib.show", ["texture" => TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["report"], "tid", [], "any", false, false, false, 22)], false);
            yield "\" target=\"_blank\">
                  <i class=\"fas fa-share\"></i>
                </a>
              </td>
              <td>";
            // line 26
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["report"], "reason", [], "any", false, false, false, 26), "html", null, true);
            yield "</td>
              <td>";
            // line 27
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v0 = $this->env->getFunction('trans')->getCallable()("front-end.report.status")) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["report"], "status", [], "any", false, false, false, 27)] ?? null) : null), "html", null, true);
            yield "</td>
              <td>";
            // line 28
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["report"], "report_at", [], "any", false, false, false, 28), "html", null, true);
            yield "</td>
            </tr>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['report'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        yield "        </tbody>
      </table>
    </div>
    <div class=\"card-footer\">
      <div class=\"float-right\">
        ";
        // line 36
        yield TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["reports"] ?? null), "links", [], "method", false, false, false, 36);
        yield "
      </div>
    </div>
  </div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/user/report.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  140 => 36,  133 => 31,  124 => 28,  120 => 27,  116 => 26,  109 => 22,  105 => 21,  101 => 19,  97 => 18,  90 => 14,  86 => 13,  82 => 12,  78 => 11,  71 => 6,  64 => 5,  53 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/user/report.twig", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/user/report.twig");
    }
}
