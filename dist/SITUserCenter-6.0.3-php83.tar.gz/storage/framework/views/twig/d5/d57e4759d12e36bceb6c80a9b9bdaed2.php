<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\Users\Administrator\Desktop\blessingskin\SITUserCenter-clean\resources\views/admin/i18n.twig */
class __TwigTemplate_b4ef3b40b1a292b40c4a8fe65bff87ea extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "admin.base";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        $this->parent = $this->loadTemplate("admin.base", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/i18n.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.i18n"), "html", null, true);
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "  <div class=\"row\">
    <div class=\"col-lg-8\"><div class=\"card\" id=\"table\"></div></div>
    <div class=\"col-lg-4\">
      <form action=\"";
        // line 9
        yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("/admin/i18n");
        yield "\" method=\"post\">
        <div class=\"card card-primary\">
          <div class=\"card-header\">
            <h3 class=\"card-title\">";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.i18n.add"), "html", null, true);
        yield "</h3>
          </div>
          <div class=\"card-body p-0\">
            ";
        // line 15
        if (TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["errors"] ?? null), "any", [], "any", false, false, false, 15)) {
            // line 16
            yield "              <div class=\"alert alert-danger m-3\">
                <i class=\"icon fas fa-exclamation-triangle\"></i>
                ";
            // line 18
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["errors"] ?? null), "first", [], "any", false, false, false, 18), "html", null, true);
            yield "
              </div>
            ";
        } elseif ($this->env->getFunction('session_pull')->getCallable()("success")) {
            // line 21
            yield "              <div class=\"alert alert-success m-3\">
                <i class=\"icon fas fa-check\"></i>
                ";
            // line 23
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.i18n.added"), "html", null, true);
            yield "
              </div>
            ";
        }
        // line 26
        yield "            ";
        yield csrf_field();
        yield "
            <div class=\"container-fluid my-4 px-4\">
              <div class=\"row mb-3\">
                <div class=\"col-sm-3\">";
        // line 29
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.i18n.group"), "html", null, true);
        yield "</div>
                <div class=\"col-sm-9\">
                  <input type=\"text\" class=\"form-control\" name=\"group\" required>
                </div>
              </div>
              <div class=\"row my-3\">
                <div class=\"col-sm-3\">";
        // line 35
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.i18n.key"), "html", null, true);
        yield "</div>
                <div class=\"col-sm-9\">
                  <input type=\"text\" class=\"form-control\" name=\"key\" required>
                </div>
              </div>
              <div class=\"row mt-3\">
                <div class=\"col-sm-3\">";
        // line 41
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.i18n.text"), "html", null, true);
        yield "</div>
                <div class=\"col-sm-9\">
                  <input type=\"text\" class=\"form-control\" name=\"text\" required>
                </div>
              </div>
            </div>
          </div>
          <div class=\"card-footer\">
            <input
              type=\"submit\"
              value=\"";
        // line 51
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.submit"), "html", null, true);
        yield "\"
              class=\"btn btn-primary\"
            >
          </div>
        </div>
      </form>
      <a class=\"btn btn-block btn-outline-info\" href=\"https://blessing.netlify.com/ui-text.html\" target=\"_blank\">
        ";
        // line 58
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.i18n.tip"), "html", null, true);
        yield "
      </a>
    </div>
  </div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/i18n.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  158 => 58,  148 => 51,  135 => 41,  126 => 35,  117 => 29,  110 => 26,  104 => 23,  100 => 21,  94 => 18,  90 => 16,  88 => 15,  82 => 12,  76 => 9,  71 => 6,  64 => 5,  53 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/i18n.twig", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/i18n.twig");
    }
}
