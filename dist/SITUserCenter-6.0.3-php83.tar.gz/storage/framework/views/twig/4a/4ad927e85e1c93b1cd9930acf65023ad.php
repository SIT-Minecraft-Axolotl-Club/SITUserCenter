<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\Users\Administrator\Desktop\blessingskin\SITUserCenter-clean\resources\views/forms/form.twig */
class __TwigTemplate_005b2777dd754b4031d68ccb8e117467 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<div class=\"card card-";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["type"] ?? null), "html", null, true);
        yield "\">
  <div class=\"card-header\">
    <h3 class=\"card-title\">";
        // line 3
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["title"] ?? null), "html", null, true);
        yield " ";
        yield ($context["hint"] ?? null);
        yield "</h3>
  </div>
  <form method=\"post\">
    ";
        // line 6
        yield csrf_field();
        yield "
    <input type=\"hidden\" name=\"option\" value=\"";
        // line 7
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
        yield "\">
    <div class=\"card-body\">
      ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["messages"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 10
            yield "        <div class=\"callout callout-";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["message"], "type", [], "any", false, false, false, 10), "html", null, true);
            yield "\">
          ";
            // line 11
            yield TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["message"], "content", [], "any", false, false, false, 11);
            yield "
        </div>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['message'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        yield "
      ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["alerts"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["alert"]) {
            // line 16
            yield "        <div class=\"alert alert-";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["alert"], "type", [], "any", false, false, false, 16), "html", null, true);
            yield "\">
          ";
            // line 17
            if ((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["alert"], "type", [], "any", false, false, false, 17) == "success")) {
                // line 18
                yield "            <i class=\"fas fa-check icon\"></i>
          ";
            } elseif ((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source,             // line 19
$context["alert"], "type", [], "any", false, false, false, 19) == "info")) {
                // line 20
                yield "            <i class=\"fas fa-info icon\"></i>
          ";
            } elseif ((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source,             // line 21
$context["alert"], "type", [], "any", false, false, false, 21) == "warning")) {
                // line 22
                yield "            <i class=\"fas fa-exclamation-triangle icon\"></i>
          ";
            } elseif ((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source,             // line 23
$context["alert"], "type", [], "any", false, false, false, 23) == "danger")) {
                // line 24
                yield "            <i class=\"fas fa-times-circle icon\"></i>
          ";
            }
            // line 26
            yield "          <span>";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["alert"], "content", [], "any", false, false, false, 26), "html", null, true);
            yield "</span>
        </div>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['alert'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        yield "
      ";
        // line 30
        if (($context["renderWithoutTable"] ?? null)) {
            // line 31
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["items"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 32
                yield "          ";
                yield TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["item"], "render", [], "method", false, false, false, 32);
                yield "
          ";
                // line 33
                if (TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["item"], "description", [], "any", false, false, false, 33)) {
                    // line 34
                    yield "            <p class=\"description\">";
                    yield TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["item"], "description", [], "any", false, false, false, 34);
                    yield "</p>
          ";
                }
                // line 36
                yield "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 37
            yield "      ";
        } else {
            // line 38
            yield "        <div class=\"container-fluid\">
          ";
            // line 39
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["items"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 40
                yield "            <div class=\"row ";
                yield (((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 40) == 1)) ? ("mb-3") : ((((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 40) == TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["loop"], "length", [], "any", false, false, false, 40))) ? ("mt-3") : ("my-3"))));
                yield "\">
              ";
                // line 41
                if ( !($context["renderInputTagsOnly"] ?? null)) {
                    // line 42
                    yield "                <div class=\"col-sm-4\">
                  ";
                    // line 43
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, false, 43), "html", null, true);
                    yield " ";
                    yield TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["item"], "hint", [], "any", false, false, false, 43);
                    yield "
                </div>
              ";
                }
                // line 46
                yield "              <div class=\"col-sm-";
                yield ((($context["renderInputTagsOnly"] ?? null)) ? ("12") : ("8"));
                yield "\">
                ";
                // line 47
                yield TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["item"], "render", [], "method", false, false, false, 47);
                yield "
                ";
                // line 48
                if (TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["item"], "description", [], "any", false, false, false, 48)) {
                    // line 49
                    yield "                  <p class=\"description\">";
                    yield TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["item"], "description", [], "any", false, false, false, 49);
                    yield "</p>
                ";
                }
                // line 51
                yield "              </div>
            </div>
          ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 54
            yield "        </div>
      ";
        }
        // line 56
        yield "    </div>
    <div class=\"card-footer\">
      ";
        // line 58
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["buttons"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["button"]) {
            // line 59
            yield "        ";
            if (TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["button"], "href", [], "any", false, false, false, 59)) {
                // line 60
                yield "          <a href=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["button"], "href", [], "any", false, false, false, 60), "html", null, true);
                yield "\" class=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["button"], "class", [], "any", false, false, false, 60), " "), "html", null, true);
                yield "\">
            ";
                // line 61
                yield TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["button"], "text", [], "any", false, false, false, 61);
                yield "
          </a>
        ";
            } else {
                // line 64
                yield "          <button
            type=\"";
                // line 65
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["button"], "type", [], "any", false, false, false, 65), "html", null, true);
                yield "\"
            name=\"";
                // line 66
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["button"], "name", [], "any", false, false, false, 66), "html", null, true);
                yield "\"
            class=\"";
                // line 67
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["button"], "class", [], "any", false, false, false, 67), " "), "html", null, true);
                yield "\"
          >
            ";
                // line 69
                yield TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["button"], "text", [], "any", false, false, false, 69);
                yield "
          </button>
        ";
            }
            // line 72
            yield "      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['button'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 73
        yield "    </div>
  </form>
</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/forms/form.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  286 => 73,  280 => 72,  274 => 69,  269 => 67,  265 => 66,  261 => 65,  258 => 64,  252 => 61,  245 => 60,  242 => 59,  238 => 58,  234 => 56,  230 => 54,  214 => 51,  208 => 49,  206 => 48,  202 => 47,  197 => 46,  189 => 43,  186 => 42,  184 => 41,  179 => 40,  162 => 39,  159 => 38,  156 => 37,  150 => 36,  144 => 34,  142 => 33,  137 => 32,  132 => 31,  130 => 30,  127 => 29,  117 => 26,  113 => 24,  111 => 23,  108 => 22,  106 => 21,  103 => 20,  101 => 19,  98 => 18,  96 => 17,  91 => 16,  87 => 15,  84 => 14,  75 => 11,  70 => 10,  66 => 9,  61 => 7,  57 => 6,  49 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/forms/form.twig", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/forms/form.twig");
    }
}
