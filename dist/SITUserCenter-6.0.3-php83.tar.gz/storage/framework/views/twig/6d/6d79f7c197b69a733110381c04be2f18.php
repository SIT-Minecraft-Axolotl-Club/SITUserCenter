<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* admin.widgets.dashboard.notification */
class __TwigTemplate_98b9ea5eb52a9d74fa8eded2a859343e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<div class=\"card\">
  <div class=\"card-header\">
    <h3 class=\"card-title\">";
        // line 3
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.notifications.send.title"), "html", null, true);
        yield "</h3>
  </div>
  <form method=\"post\" action=\"";
        // line 5
        yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("/admin/notifications/send");
        yield "\">
    ";
        // line 6
        yield csrf_field();
        yield "
    <div class=\"card-body\">
      ";
        // line 8
        if (TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["errors"] ?? null), "any", [], "any", false, false, false, 8)) {
            // line 9
            yield "        <div class=\"callout callout-danger\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["errors"] ?? null), "first", [], "any", false, false, false, 9), "html", null, true);
            yield "</div>
      ";
        }
        // line 11
        yield "      ";
        $context["sent_result"] = $this->env->getFunction('session_pull')->getCallable()("sentResult");
        // line 12
        yield "      ";
        if (($context["sent_result"] ?? null)) {
            // line 13
            yield "        <div class=\"callout callout-success\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["sent_result"] ?? null), "html", null, true);
            yield "</div>
      ";
        }
        // line 15
        yield "      <div class=\"form-group\">
        <label>";
        // line 16
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.notifications.receiver.title"), "html", null, true);
        yield "</label>
        <div class=\"radio\">
        <label>
          <input type=\"radio\" name=\"receiver\" value=\"all\" required>
          ";
        // line 20
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.notifications.receiver.all"), "html", null, true);
        yield "
        </label>
        </div>
        <div class=\"radio\">
          <label>
            <input type=\"radio\" name=\"receiver\" value=\"normal\" required>
            ";
        // line 26
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.notifications.receiver.normal"), "html", null, true);
        yield "
          </label>
        </div>
        <div class=\"radio\">
          <label>
            <input type=\"radio\" name=\"receiver\" value=\"uid\" required>
            ";
        // line 32
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.notifications.receiver.uid"), "html", null, true);
        yield " &nbsp;
            <input type=\"number\" name=\"uid\" class=\"form-control\">
          </label>
        </div>
        <div class=\"radio\">
          <label>
            <input type=\"radio\" name=\"receiver\" value=\"email\" required>
            ";
        // line 39
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.notifications.receiver.email"), "html", null, true);
        yield " &nbsp;
            <input type=\"email\" name=\"email\" class=\"form-control\">
          </label>
        </div>
      </div>
      <div class=\"form-group\">
        <label>";
        // line 45
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.notifications.title"), "html", null, true);
        yield "</label>
        <input type=\"text\" name=\"title\" class=\"form-control\" required>
      </div>
      <div class=\"form-group\">
        <label>";
        // line 49
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.notifications.content"), "html", null, true);
        yield "</label>
        <textarea name=\"content\" class=\"form-control\" rows=\"3\"></textarea>
      </div>
    </div>
    <div class=\"card-footer\">
      <input
        type=\"submit\"
        value=\"";
        // line 56
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.submit"), "html", null, true);
        yield "\"
        class=\"btn btn-primary\"
      >
    </div>
  </form>
</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "admin.widgets.dashboard.notification";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  145 => 56,  135 => 49,  128 => 45,  119 => 39,  109 => 32,  100 => 26,  91 => 20,  84 => 16,  81 => 15,  75 => 13,  72 => 12,  69 => 11,  63 => 9,  61 => 8,  56 => 6,  52 => 5,  47 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "admin.widgets.dashboard.notification", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/widgets/dashboard/notification.twig");
    }
}
