<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* shared.dark-mode */
class __TwigTemplate_e359fc78ff7ca3b3e84485a1f0fbabef extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        if ($this->env->getFunction('auth_check')->getCallable()()) {
            // line 2
            yield "  <li class=\"nav-item\" id=\"toggle-dark-mode\">
    <a class=\"nav-link\" href=\"#\" role=\"button\">
      <i class=\"fas fa-";
            // line 4
            yield ((($context["dark_mode"] ?? null)) ? ("moon") : ("sun"));
            yield "\"></i>
    </a>
  </li>
";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "shared.dark-mode";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  49 => 4,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "shared.dark-mode", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/shared/dark-mode.twig");
    }
}
