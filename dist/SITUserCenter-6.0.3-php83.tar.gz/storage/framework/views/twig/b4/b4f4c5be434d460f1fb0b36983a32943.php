<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* skinlib.base */
class __TwigTemplate_78b3e996b18dcfece798ba5b4e8bf3cf extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
            'before_foot' => [$this, 'block_before_foot'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<!DOCTYPE html>
<html lang=\"";
        // line 2
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["locale"] ?? null), "html", null, true);
        yield "\">
  <head>
    ";
        // line 4
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.head");
        yield "
    <title>";
        // line 5
        yield from $this->unwrap()->yieldBlock('title', $context, $blocks);
        yield " - ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_name"] ?? null), "html", null, true);
        yield "</title>
  </head>

  <body class=\"";
        // line 8
        yield ((($context["dark_mode"] ?? null)) ? ("dark-mode") : (""));
        yield " hold-transition layout-top-nav\">
    <div class=\"wrapper\">
      <nav class=\"main-header navbar navbar-expand navbar-";
        // line 10
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["navbar_color"] ?? null), "html", null, true);
        yield " navbar-";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color_mode"] ?? null), "html", null, true);
        yield " ml-0\">
        <div class=\"container\">
          <div class=\"navbar-header\">
            <a href=\"";
        // line 13
        yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("/");
        yield "\" class=\"navbar-brand\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_name"] ?? null), "html", null, true);
        yield "</a>
          </div>

          <div class=\"collapse navbar-collapse\">
            <ul class=\"nav navbar-nav\">
              <li class=\"nav-item active\">
                <a class=\"nav-link\" href=\"";
        // line 19
        yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("skinlib");
        yield "\">
                  ";
        // line 20
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.skinlib"), "html", null, true);
        yield "
                </a>
              </li>
              ";
        // line 23
        if ($this->env->getFunction('auth_check')->getCallable()()) {
            // line 24
            yield "                <li class=\"nav-item\">
                  <a class=\"nav-link\" href=\"";
            // line 25
            yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("user/closet");
            yield "\">
                    ";
            // line 26
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.my-closet"), "html", null, true);
            yield "
                  </a>
                </li>
              ";
        }
        // line 30
        yield "            </ul>
          </div>

          <div class=\"navbar-custom-menu\">
            <ul class=\"nav navbar-nav\">
              ";
        // line 35
        if ($this->env->getFunction('auth_check')->getCallable()()) {
            // line 36
            yield "                <li class=\"nav-item\">
                  <a class=\"nav-link\" href=\"";
            // line 37
            yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("skinlib/upload");
            yield "\">
                    <i class=\"fas fa-upload\" aria-hidden=\"true\"></i>&nbsp;
                    <span class=\"d-none d-sm-inline\">
                      ";
            // line 40
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("skinlib.general.upload-new-skin"), "html", null, true);
            yield "
                    </span>
                  </a>
                </li>
                ";
            // line 44
            yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.notifications");
            yield "
              ";
        }
        // line 46
        yield "              ";
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.languages");
        yield "
              ";
        // line 47
        if ($this->env->getFunction('auth_check')->getCallable()()) {
            // line 48
            yield "                ";
            yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.user-menu");
            yield "
              ";
        } else {
            // line 50
            yield "                <li class=\"nav-item\">
                  <a class=\"nav-link\" href=\"";
            // line 51
            yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("auth/login");
            yield "\">
                    <i class=\"fas fa-user\"></i>
                    <span class=\"d-none d-sm-inline\">
                      ";
            // line 54
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.anonymous"), "html", null, true);
            yield "
                    </span>
                  </a>
                </li>
              ";
        }
        // line 59
        yield "            </ul>
          </div>
        </div>
      </nav>

      ";
        // line 64
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 65
        yield "
      <footer class=\"main-footer\">
        <div class=\"container\">
          ";
        // line 68
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.copyright");
        yield "
        </div>
      </footer>
    </div>
    ";
        // line 72
        yield from $this->unwrap()->yieldBlock('before_foot', $context, $blocks);
        // line 73
        yield "    ";
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.foot");
        yield "
  </body>
</html>
";
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 64
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 72
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_before_foot(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "skinlib.base";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  229 => 72,  219 => 64,  209 => 5,  199 => 73,  197 => 72,  190 => 68,  185 => 65,  183 => 64,  176 => 59,  168 => 54,  162 => 51,  159 => 50,  153 => 48,  151 => 47,  146 => 46,  141 => 44,  134 => 40,  128 => 37,  125 => 36,  123 => 35,  116 => 30,  109 => 26,  105 => 25,  102 => 24,  100 => 23,  94 => 20,  90 => 19,  79 => 13,  71 => 10,  66 => 8,  58 => 5,  54 => 4,  49 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "skinlib.base", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/skinlib/base.twig");
    }
}
