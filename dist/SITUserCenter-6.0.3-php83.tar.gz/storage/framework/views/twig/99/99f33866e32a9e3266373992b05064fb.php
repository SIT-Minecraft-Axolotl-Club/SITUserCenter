<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user.widgets.profile.nickname */
class __TwigTemplate_20f5345fc646e46c4b8177ab730651a4 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<form class=\"card card-primary\" method=\"post\" id=\"change-nickname\">
  <div class=\"card-header\">
    <h3 class=\"card-title\">
      ";
        // line 4
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.profile.nickname.title"), "html", null, true);
        yield "
    </h3>
  </div>
  <div class=\"card-body\">
    <div class=\"form-group\">
      <input type=\"text\" class=\"form-control\" name=\"nickname\" required
        value=\"";
        // line 10
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["user"] ?? null), "nickname", [], "any", false, false, false, 10), "html", null, true);
        yield "\">
    </div>
  </div>
  <div class=\"card-footer\">
    <button class=\"btn btn-primary\" type=\"submit\">
      ";
        // line 15
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.submit"), "html", null, true);
        yield "
    </button>
  </div>
</form>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user.widgets.profile.nickname";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  65 => 15,  57 => 10,  48 => 4,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user.widgets.profile.nickname", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/user/widgets/profile/nickname.twig");
    }
}
