<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\Users\Administrator\Desktop\blessingskin\SITUserCenter-clean\resources\views/admin/update.twig */
class __TwigTemplate_4d0db553570229c3603301c3b122d7a9 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "admin.base";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        $this->parent = $this->loadTemplate("admin.base", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/update.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.check-update"), "html", null, true);
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "  <div class=\"row\">
    <div class=\"col-md-6\">
      <div class=\"card card-primary\">
        <div class=\"card-header\">
          <h3 class=\"card-title\">";
        // line 10
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.info.title"), "html", null, true);
        yield "</h3>
        </div>
        <div class=\"card-body\">
          ";
        // line 13
        if (($context["can_update"] ?? null)) {
            // line 14
            yield "            <div class=\"callout callout-info\">
              ";
            // line 15
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.info.available"), "html", null, true);
            yield "
            </div>
            <div class=\"container-fluid\">
              <div class=\"row mb-3\">
                <div class=\"col-sm-4\">
                  ";
            // line 20
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.info.versions.latest"), "html", null, true);
            yield "
                </div>
                <div class=\"col-sm-8\">
                  v";
            // line 23
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["info"] ?? null), "latest", [], "any", false, false, false, 23), "html", null, true);
            yield "
                </div>
              </div>
              <div class=\"row mt-3\">
                <div class=\"col-sm-4\">
                  ";
            // line 28
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.info.versions.current"), "html", null, true);
            yield "
                </div>
                <div class=\"col-sm-8\">
                  v";
            // line 31
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["info"] ?? null), "current", [], "any", false, false, false, 31), "html", null, true);
            yield "
                </div>
              </div>
            </div>
          ";
        } else {
            // line 36
            yield "            ";
            if (($context["error"] ?? null)) {
                // line 37
                yield "              <div class=\"callout callout-danger\">
                ";
                // line 38
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.errors.connection", ["error" => ($context["error"] ?? null)]), "html", null, true);
                yield "
              </div>
            ";
            } else {
                // line 41
                yield "              <div class=\"callout callout-success\">
                ";
                // line 42
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.info.up-to-date"), "html", null, true);
                yield "
              </div>
            ";
            }
            // line 45
            yield "            <div class=\"container-fluid\">
              <div class=\"row\">
                <div class=\"col-sm-4\">
                  ";
            // line 48
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.info.versions.current"), "html", null, true);
            yield "
                </div>
                <div class=\"col-sm-8\">
                  v";
            // line 51
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["info"] ?? null), "current", [], "any", false, false, false, 51), "html", null, true);
            yield "
                </div>
              </div>
            </div>
          ";
        }
        // line 56
        yield "        </div>
        <div class=\"card-footer\">
          ";
        // line 58
        if (($context["can_update"] ?? null)) {
            // line 59
            yield "            <button class=\"btn bg-primary\" id=\"update\">
              ";
            // line 60
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.info.button"), "html", null, true);
            yield "
            </button>
          ";
        } else {
            // line 63
            yield "            <button class=\"btn bg-primary\" disabled=\"disabled\">
              ";
            // line 64
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.info.button"), "html", null, true);
            yield "
            </button>
          ";
        }
        // line 67
        yield "          <a
            target=\"_blank\"
            class=\"btn btn-default float-right\"
            href=\"https://github.com/bs-community/blessing-skin-server/releases\"
          >
            ";
        // line 72
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.info.check-github"), "html", null, true);
        yield "
          </a>
        </div>
      </div>
    </div>
    <div class=\"col-md-6\">
      <div class=\"card card-info\">
        <div class=\"card-header\">
          <h3 class=\"card-title\">
            ";
        // line 81
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.cautions.title"), "html", null, true);
        yield "
          </h3>
        </div>
        <div class=\"card-body\">
          ";
        // line 85
        yield Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.cautions.text"), "html", null, true));
        yield "
          <a target=\"_blank\" href=\"https://blessing.netlify.com/update-sources.html\">
            ";
        // line 87
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("admin.update.cautions.link"), "html", null, true);
        yield "
          </a>
        </div>
      </div>
    </div>
  </div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/update.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  219 => 87,  214 => 85,  207 => 81,  195 => 72,  188 => 67,  182 => 64,  179 => 63,  173 => 60,  170 => 59,  168 => 58,  164 => 56,  156 => 51,  150 => 48,  145 => 45,  139 => 42,  136 => 41,  130 => 38,  127 => 37,  124 => 36,  116 => 31,  110 => 28,  102 => 23,  96 => 20,  88 => 15,  85 => 14,  83 => 13,  77 => 10,  71 => 6,  64 => 5,  53 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/update.twig", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/update.twig");
    }
}
