<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* shared.side-menu-item */
class __TwigTemplate_7db4d76eeec6e4276c43b566bf9adc81 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<li class=\"nav-item ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["item"] ?? null), "classes", [], "any", false, false, false, 1), " "), "html", null, true);
        yield "\">
  ";
        // line 2
        if (TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["item"] ?? null), "children", [], "any", false, false, false, 2)) {
            // line 3
            yield "    <a class=\"nav-link ";
            yield ((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["item"] ?? null), "active", [], "any", false, false, false, 3)) ? ("active") : (""));
            yield "\" href=\"#\">
      <i class=\"nav-icon fas ";
            // line 4
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["item"] ?? null), "icon", [], "any", false, false, false, 4), "html", null, true);
            yield "\"></i>
      <p class=\"ml-1\">";
            // line 5
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["item"] ?? null), "title", [], "any", false, false, false, 5)), "html", null, true);
            yield "</p>
      <i class=\"right fas fa-angle-left\"></i>
    </a>
    <ul class=\"nav nav-treeview\">
      ";
            // line 9
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["item"] ?? null), "children", [], "any", false, false, false, 9));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 10
                yield "        ";
                yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.side-menu-item", ["item" => $context["child"]]);
                yield "
      ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 12
            yield "    </ul>
  ";
        } else {
            // line 14
            yield "    <a
      href=\"";
            // line 15
            yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["item"] ?? null), "link", [], "any", false, false, false, 15));
            yield "\"
      class=\"nav-link ";
            // line 16
            yield ((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["item"] ?? null), "active", [], "any", false, false, false, 16)) ? ("active") : (""));
            yield "\"
      ";
            // line 17
            if (TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["item"] ?? null), "new-tab", [], "any", false, false, false, 17)) {
                // line 18
                yield "        target=\"_blank\"
        rel=\"noopener noreferrer\"
      ";
            }
            // line 21
            yield "    >
      <i class=\"nav-icon ";
            // line 22
            yield (((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["item"] ?? null), "icon", [], "any", false, false, false, 22) == "fa-circle")) ? ("far") : ("fas"));
            yield " ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["item"] ?? null), "icon", [], "any", false, false, false, 22), "html", null, true);
            yield "\"></i>
      <p class=\"ml-1\">";
            // line 23
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["item"] ?? null), "title", [], "any", false, false, false, 23)), "html", null, true);
            yield "</p>
    </a>
  ";
        }
        // line 26
        yield "</li>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "shared.side-menu-item";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  137 => 26,  131 => 23,  125 => 22,  122 => 21,  117 => 18,  115 => 17,  111 => 16,  107 => 15,  104 => 14,  100 => 12,  83 => 10,  66 => 9,  59 => 5,  55 => 4,  50 => 3,  48 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "shared.side-menu-item", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/shared/side-menu-item.twig");
    }
}
