<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user.widgets.profile.delete-account */
class __TwigTemplate_1f2b7e8ace3af52cc8698d784567ba2d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<div class=\"card card-danger\">
  <div class=\"card-header\">
    <h3 class=\"card-title\">
      ";
        // line 4
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.profile.delete.title"), "html", null, true);
        yield "
    </h3>
  </div>
  <div class=\"card-body\">
    ";
        // line 8
        if (TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["user"] ?? null), "admin", [], "any", false, false, false, 8)) {
            // line 9
            yield "      <p>";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.profile.delete.admin"), "html", null, true);
            yield "</p>
      <button class=\"btn btn-danger\" disabled=\"disabled\">
        ";
            // line 11
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.profile.delete.button"), "html", null, true);
            yield "
      </button>
    ";
        } else {
            // line 14
            yield "      <p>";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.profile.delete.notice", ["site" => ($context["site_name"] ?? null)]), "html", null, true);
            yield "</p>
      <button
        class=\"btn btn-danger\"
        data-toggle=\"modal\"
        data-target=\"#modal-delete-account\"
      >
        ";
            // line 20
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("user.profile.delete.button"), "html", null, true);
            yield "
      </button>
    ";
        }
        // line 23
        yield "  </div>
</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user.widgets.profile.delete-account";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  85 => 23,  79 => 20,  69 => 14,  63 => 11,  57 => 9,  55 => 8,  48 => 4,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user.widgets.profile.delete-account", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/user/widgets/profile/delete-account.twig");
    }
}
