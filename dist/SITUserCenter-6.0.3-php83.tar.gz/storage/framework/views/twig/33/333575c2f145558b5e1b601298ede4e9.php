<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* admin.base */
class __TwigTemplate_6f18e066fddd10d4d4a057edb6fb2bcb extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
            'before_foot' => [$this, 'block_before_foot'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<!DOCTYPE html>
<html lang=\"";
        // line 2
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["locale"] ?? null), "html", null, true);
        yield "\">
  <head>
    ";
        // line 4
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.head");
        yield "
    <title>";
        // line 5
        yield from $this->unwrap()->yieldBlock('title', $context, $blocks);
        yield " - ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_name"] ?? null), "html", null, true);
        yield "</title>
  </head>

  <body class=\"";
        // line 8
        yield ((($context["dark_mode"] ?? null)) ? ("dark-mode") : (""));
        yield " hold-transition sidebar-mini\">
    <div class=\"wrapper\">
      ";
        // line 10
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.header");
        yield "
      ";
        // line 11
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.sidebar", ["scope" => "admin"]);
        yield "
      <div class=\"content-wrapper\">
        <div class=\"content-header\">
          <div class=\"container-fluid\">
            <div class=\"d-flex justify-content-between flex-wrap\">
              <div>
                <h1 class=\"m-0\">";
        // line 17
        yield from         $this->unwrap()->yieldBlock("title", $context, $blocks);
        yield "</h1>
              </div>
              <div>
                <div class=\"breadcrumb\"></div>
              </div>
            </div>
          </div>
        </div>
        <section class=\"content\">
          <div class=\"container-fluid\">
            ";
        // line 27
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 28
        yield "          </div>
        </section>
      </div>
      <footer class=\"main-footer\">
        ";
        // line 32
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.copyright");
        yield "
      </footer>
    </div>
    ";
        // line 35
        yield from $this->unwrap()->yieldBlock('before_foot', $context, $blocks);
        // line 36
        yield "    ";
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.foot");
        yield "
  </body>
</html>
";
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 27
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 35
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_before_foot(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "admin.base";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  143 => 35,  133 => 27,  123 => 5,  113 => 36,  111 => 35,  105 => 32,  99 => 28,  97 => 27,  84 => 17,  75 => 11,  71 => 10,  66 => 8,  58 => 5,  54 => 4,  49 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "admin.base", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/admin/base.twig");
    }
}
