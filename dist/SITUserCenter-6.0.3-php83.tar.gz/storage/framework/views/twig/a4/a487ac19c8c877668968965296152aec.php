<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* shared.sidebar */
class __TwigTemplate_64e81c3cee7476fdc4e53cc668086154 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<aside class=\"main-sidebar sidebar-";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["sidebar_color"] ?? null), "html", null, true);
        yield " elevation-3\">
  <a href=\"";
        // line 2
        yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("/");
        yield "\" class=\"brand-link text-center\">
    <span class=\"brand-text font-weight-light\">";
        // line 3
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_name"] ?? null), "html", null, true);
        yield "</span>
  </a>
  <div class=\"sidebar\">
    ";
        // line 6
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.user-panel");
        yield "
    <nav class=\"mt-2\">
      <ul
        class=\"nav nav-pills nav-sidebar flex-column nav-child-indent\"
        data-widget=\"treeview\"
        role=\"menu\"
      >

        ";
        // line 14
        if ((($context["scope"] ?? null) == "user")) {
            // line 15
            yield "
          <li class=\"nav-header\">";
            // line 16
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.user-center"), "html", null, true);
            yield "</li>
          ";
            // line 17
            yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.side-menu", ["type" => "user"]);
            yield "
          <li class=\"nav-header\">";
            // line 18
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.explore"), "html", null, true);
            yield "</li>
          ";
            // line 19
            yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.side-menu", ["type" => "explore"]);
            yield "
          ";
            // line 20
            if (TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $this->env->getFunction('auth_user')->getCallable()(), "admin", [], "any", false, false, false, 20)) {
                // line 21
                yield "            <li class=\"nav-header\">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.manage"), "html", null, true);
                yield "</li>
            <li class=\"nav-item\">
              <a class=\"nav-link\" href=\"";
                // line 23
                yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("admin");
                yield "\">
                <i class=\"nav-icon fas fa-cog\"></i>
                <p>";
                // line 25
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.admin-panel"), "html", null, true);
                yield "</p>
              </a>
            </li>
          ";
            }
            // line 29
            yield "
        ";
        } elseif ((        // line 30
($context["scope"] ?? null) == "admin")) {
            // line 31
            yield "
          <li class=\"nav-header\">";
            // line 32
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.admin-panel"), "html", null, true);
            yield "</li>
          ";
            // line 33
            yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.side-menu", ["type" => "admin"]);
            yield "
          <li class=\"nav-header\">";
            // line 34
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.back"), "html", null, true);
            yield "</li>
          <li class=\"nav-item\">
            <a class=\"nav-link\" href=\"";
            // line 36
            yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("user");
            yield "\">
              <i class=\"nav-icon fas fa-user\"></i> &nbsp;
              <p>";
            // line 38
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.user-center"), "html", null, true);
            yield "</p>
            </a>
          </li>
          <li class=\"nav-item\">
            <a class=\"nav-link\" href=\"";
            // line 42
            yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("skinlib");
            yield "\">
              <i class=\"nav-icon fas fa-archive\"></i> &nbsp;
              <p>";
            // line 44
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.skinlib"), "html", null, true);
            yield "</p>
            </a>
          </li>

        ";
        }
        // line 49
        yield "
      </ul>
    </nav>
  </div>
</aside>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "shared.sidebar";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  156 => 49,  148 => 44,  143 => 42,  136 => 38,  131 => 36,  126 => 34,  122 => 33,  118 => 32,  115 => 31,  113 => 30,  110 => 29,  103 => 25,  98 => 23,  92 => 21,  90 => 20,  86 => 19,  82 => 18,  78 => 17,  74 => 16,  71 => 15,  69 => 14,  58 => 6,  52 => 3,  48 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "shared.sidebar", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/shared/sidebar.twig");
    }
}
