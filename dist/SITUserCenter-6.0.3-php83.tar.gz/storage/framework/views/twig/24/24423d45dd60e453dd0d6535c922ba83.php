<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* shared.user-menu */
class __TwigTemplate_c8aaaa6b60e811606e07fe0eded5ef0c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<li class=\"nav-item dropdown user-menu\">
  <a href=\"#\" class=\"nav-link d-flex align-items-center\" data-toggle=\"dropdown\">
    <picture>
      <source srcset=\"";
        // line 4
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["avatar"] ?? null), "html", null, true);
        yield "\" type=\"image/webp\">
      <img src=\"";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["avatar_png"] ?? null), "html", null, true);
        yield "\" class=\"bs-avatar mr-2\" alt=\"User Image\">
    </picture>
    <span class=\"d-none d-md-inline d-sm-block\" data-mark=\"nickname\">
      ";
        // line 8
        yield (((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["user"] ?? null), "nickname", [], "any", true, true, false, 8) &&  !(null === TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["user"] ?? null), "nickname", [], "any", false, false, false, 8)))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["user"] ?? null), "nickname", [], "any", false, false, false, 8), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["user"] ?? null), "email", [], "any", false, false, false, 8), "html", null, true)));
        yield "
    </span>
  </a>

  <div class=\"dropdown-menu dropdown-menu-lg dropdown-menu-right\">
    ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["menu"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 14
            yield "      ";
            if ((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["item"], "link", [], "any", false, false, false, 14) == "#divider")) {
                // line 15
                yield "        <div class=\"dropdown-divider\"></div>
      ";
            } else {
                // line 17
                yield "        <a class=\"dropdown-item\" href=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["item"], "link", [], "any", false, false, false, 17), "html", null, true);
                yield "\">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["item"], "label", [], "any", false, false, false, 17), "html", null, true);
                yield "</a>
      ";
            }
            // line 19
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        yield "    <div class=\"dropdown-divider\"></div>
    <a class=\"dropdown-item\" href=\"#\" id=\"logout-button\">
      ";
        // line 22
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.logout"), "html", null, true);
        yield "
    </a>
  </div>
</li>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "shared.user-menu";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  95 => 22,  91 => 20,  85 => 19,  77 => 17,  73 => 15,  70 => 14,  66 => 13,  58 => 8,  52 => 5,  48 => 4,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "shared.user-menu", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/shared/user-menu.twig");
    }
}
