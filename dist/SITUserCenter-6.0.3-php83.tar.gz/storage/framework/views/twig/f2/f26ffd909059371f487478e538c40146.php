<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\Users\Administrator\Desktop\blessingskin\SITUserCenter-clean\resources\views/home.twig */
class __TwigTemplate_d31bbd446ef981d2d6c5bdf930c5de71 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<!DOCTYPE html>
<html lang=\"";
        // line 2
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["locale"] ?? null), "html", null, true);
        yield "\">
  <head>
    ";
        // line 4
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.head");
        yield "
    <link rel=\"preload\" as=\"image\" href=\"";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["home_pic_url"] ?? null), "html", null, true);
        yield "\">
    <title>";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_name"] ?? null), "html", null, true);
        yield "</title>
    <style>
      .hp-wrapper {
        ";
        // line 9
        if (($context["fixed_bg"] ?? null)) {
            // line 10
            yield "          background-color: rgba(0, 0, 0, 0);
        ";
        } else {
            // line 12
            yield "          background-image: url('";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["home_pic_url"] ?? null), "html", null, true);
            yield "');
        ";
        }
        // line 14
        yield "      }
    </style>
    ";
        // line 16
        yield Twig\Extension\CoreExtension::include($this->env, $context, "assets.home-css", [], true, true);
        yield "
  </head>

  <body class=\"hold-transition layout-top-nav\">
    <div class=\"hp-wrapper\">
      ";
        // line 21
        if (($context["fixed_bg"] ?? null)) {
            // line 22
            yield "        <div id=\"fixed-bg\" style=\"background-image: url('";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["home_pic_url"] ?? null), "html", null, true);
            yield "')\"></div>
      ";
        }
        // line 24
        yield "
      <nav class=\"navbar navbar-expand fixed-top navbar-";
        // line 25
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["navbar_color"] ?? null), "html", null, true);
        yield " navbar-";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color_mode"] ?? null), "html", null, true);
        yield "
        ml-0 ";
        // line 26
        yield ((($context["transparent_navbar"] ?? null)) ? ("transparent") : (""));
        yield "\"
      >
        <div class=\"container\">
          <div class=\"navbar-header\">
            <a href=\"";
        // line 30
        yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("/");
        yield "\" class=\"navbar-brand\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_name"] ?? null), "html", null, true);
        yield "</a>
          </div>

          <div class=\"navbar-custom-menu\">
            <ul class=\"nav navbar-nav\">
              <li class=\"nav-item\">
                <a class=\"nav-link\" href=\"";
        // line 36
        yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("skinlib");
        yield "\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.skinlib"), "html", null, true);
        yield "</a>
              </li>

              ";
        // line 39
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.languages");
        yield "

              ";
        // line 41
        if ($this->env->getFunction('auth_check')->getCallable()()) {
            // line 42
            yield "                ";
            yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.user-menu");
            yield "
              ";
        } else {
            // line 44
            yield "                <li class=\"nav-item\">
                  <a class=\"nav-link\" href=\"";
            // line 45
            yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("auth/login");
            yield "\">
                    <i class=\"icon fas fa-sign-in-alt\"></i>
                    ";
            // line 47
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.login"), "html", null, true);
            yield "
                  </a>
                </li>
              ";
        }
        // line 51
        yield "            </ul>
          </div>
        </div>
      </nav>

      <div class=\"container\">
        <div class=\"splash\">
          <h1 class=\"splash-head\">";
        // line 58
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_name"] ?? null), "html", null, true);
        yield "</h1>
          <p class=\"splash-subhead\">
            ";
        // line 60
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_description"] ?? null), "html", null, true);
        yield "
          </p>
          <p>
            ";
        // line 63
        if ($this->env->getFunction('auth_check')->getCallable()()) {
            // line 64
            yield "              <a href=\"";
            yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("user");
            yield "\" class=\"main-button\">
                ";
            // line 65
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.user-center"), "html", null, true);
            yield "
              </a>
            ";
        } else {
            // line 68
            yield "              <a href=\"";
            yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("/auth/register");
            yield "\" class=\"main-button\">
                ";
            // line 69
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.register"), "html", null, true);
            yield "
              </a>
            ";
        }
        // line 72
        yield "          </p>
        </div>
      </div>

      ";
        // line 76
        if (($context["hide_intro"] ?? null)) {
            // line 77
            yield "        <div id=\"copyright\" class=\"without-intro\">
          <div class=\"container\">
            ";
            // line 79
            yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.copyright");
            yield "
          </div>
        </div>
      ";
        }
        // line 83
        yield "    </div>

    ";
        // line 85
        if ( !($context["hide_intro"] ?? null)) {
            // line 86
            yield "      <div id=\"intro\">
        <div class=\"container\">
          <div class=\"text-center\">
            <h1>";
            // line 89
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("index.features.title"), "html", null, true);
            yield "</h1>
            <br>
            <br>
            <div class=\"container-lg\">
              <div class=\"row\">
                ";
            // line 94
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(["first", "second", "third"]);
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 95
                yield "                  <div class=\"col-lg\">
                    <i class=\"fas ";
                // line 96
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()((("index.features." . $context["item"]) . ".icon")), "html", null, true);
                yield " mb-3\" aria-hidden=\"true\"></i>
                    <h3>";
                // line 97
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()((("index.features." . $context["item"]) . ".name")), "html", null, true);
                yield "</h3>
                    <p>";
                // line 98
                yield $this->env->getFunction('trans')->getCallable()((("index.features." . $context["item"]) . ".desc"));
                yield "</p>
                  </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 101
            yield "              </div>
            </div>
          </div>
          <br>
        </div>
      </div>
      <div id=\"footer-wrap\">
        <div class=\"container\">
          <div class=\"row\">
            <div class=\"col-lg-6 mb-2\">
              ";
            // line 111
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("index.introduction", ["sitename" => ($context["site_name"] ?? null)]), "html", null, true);
            yield "
            </div>
            <div class=\"col-lg-4\"></div>
            <div class=\"col-lg-2 d-flex justify-content-center align-items-center\">
              <a href=\"";
            // line 115
            yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("auth/register");
            yield "\" class=\"main-button\">
                ";
            // line 116
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("index.start"), "html", null, true);
            yield "
              </a>
            </div>
          </div>
        </div>
      </div>
      <div id=\"copyright\" class=\"with-intro\">
        <div class=\"container\">
          ";
            // line 124
            yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.copyright");
            yield "
        </div>
      </div>
    ";
        }
        // line 128
        yield "
    <script type=\"application/json\" id=\"blessing-extra\">
      ";
        // line 130
        yield json_encode(["transparent_navbar" => ($context["transparent_navbar"] ?? null)]);
        yield "
    </script>
    ";
        // line 132
        yield Twig\Extension\CoreExtension::include($this->env, $context, "assets.home", [], true, true);
        yield "
    ";
        // line 133
        yield Twig\Extension\CoreExtension::include($this->env, $context, "shared.foot");
        yield "
  </body>
</html>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/home.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  320 => 133,  316 => 132,  311 => 130,  307 => 128,  300 => 124,  289 => 116,  285 => 115,  278 => 111,  266 => 101,  257 => 98,  253 => 97,  249 => 96,  246 => 95,  242 => 94,  234 => 89,  229 => 86,  227 => 85,  223 => 83,  216 => 79,  212 => 77,  210 => 76,  204 => 72,  198 => 69,  193 => 68,  187 => 65,  182 => 64,  180 => 63,  174 => 60,  169 => 58,  160 => 51,  153 => 47,  148 => 45,  145 => 44,  139 => 42,  137 => 41,  132 => 39,  124 => 36,  113 => 30,  106 => 26,  100 => 25,  97 => 24,  91 => 22,  89 => 21,  81 => 16,  77 => 14,  71 => 12,  67 => 10,  65 => 9,  59 => 6,  55 => 5,  51 => 4,  46 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/home.twig", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/home.twig");
    }
}
