<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* shared.user-panel */
class __TwigTemplate_b6662e0014395bbeb6cb52ffc68a653b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        // line 1
        yield "<div class=\"user-panel mt-3 mb-3 ";
        yield (((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["badges"] ?? null)) > 0)) ? ("pb-2") : (""));
        yield "\">
  <div class=\"d-flex\">
    <div class=\"image\">
      <picture>
        <source srcset=\"";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["avatar"] ?? null), "html", null, true);
        yield "\" type=\"image/webp\">
        <img src=\"";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["avatar_png"] ?? null), "html", null, true);
        yield "\" class=\"bs-avatar\" alt=\"User Image\">
      </picture>
    </div>
    <div class=\"info\">
      <a class=\"d-block\" data-mark=\"nickname\">";
        // line 10
        yield (((TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["user"] ?? null), "nickname", [], "any", true, true, false, 10) &&  !(null === TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["user"] ?? null), "nickname", [], "any", false, false, false, 10)))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["user"] ?? null), "nickname", [], "any", false, false, false, 10), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["user"] ?? null), "email", [], "any", false, false, false, 10), "html", null, true)));
        yield "</a>
    </div>
  </div>

  <div class=\"mt-3 ml-2 mr-2 d-flex flex-wrap\">
    ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["badges"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["badge"]) {
            // line 16
            yield "      <span class=\"badge bg-";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["badge"], "color", [], "any", false, false, false, 16), "html", null, true);
            yield " mb-1 mr-2\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, $context["badge"], "text", [], "any", false, false, false, 16), "html", null, true);
            yield "</span>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['badge'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        yield "  </div>
</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "shared.user-panel";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  85 => 18,  74 => 16,  70 => 15,  62 => 10,  55 => 6,  51 => 5,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "shared.user-panel", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/shared/user-panel.twig");
    }
}
