<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\Users\Administrator\Desktop\blessingskin\SITUserCenter-clean\resources\views/setup/wizard/database.twig */
class __TwigTemplate_75a3ecf453b2640acf88185c06a35f00 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'subtitle' => [$this, 'block_subtitle'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "setup.base";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        $this->parent = $this->loadTemplate("setup.base", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/setup/wizard/database.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_subtitle(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("setup.wizard.database.title"), "html", null, true);
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "  <p>";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("setup.wizard.database.text"), "html", null, true);
        yield "</p>
  <form
    id=\"setup\"
    method=\"post\"
    action=\"";
        // line 10
        yield $this->extensions['TwigBridge\Extension\Laravel\Url']->url("setup/database");
        yield "\"
    novalidate=\"novalidate\"
  >
    ";
        // line 13
        yield csrf_field();
        yield "
    <table>
      <tr>
        <th>
          <label for=\"type\" class=\"form-label\">";
        // line 17
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("setup.wizard.database.type"), "html", null, true);
        yield "</label>
        </th>
        <td class=\"form-group\">
          <label class=\"form-radio d-inline-block\">
            <input name=\"type\" type=\"radio\" value=\"mysql\" id=\"type-mysql\" checked>
            <i class=\"form-icon\"></i> MySQL / MariaDB
          </label>
          <label class=\"form-radio d-inline-block\">
            <input name=\"type\" type=\"radio\" value=\"pgsql\" id=\"type-pgsql\">
            <i class=\"form-icon\"></i> PostgreSQL
          </label>
          <label class=\"form-radio d-inline-block\">
            <input name=\"type\" type=\"radio\" value=\"sqlite\" id=\"type-sqlite\">
            <i class=\"form-icon\"></i> SQLite
          </label>
        </td>
      </tr>
      <tr>
        <th>
          <label class=\"form-label\" for=\"host\">";
        // line 36
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("setup.wizard.database.host"), "html", null, true);
        yield "</label>
        </th>
        <td>
          <input
            class=\"form-input\"
            name=\"host\"
            type=\"text\"
            id=\"host\"
            size=\"25\"
            value=\"";
        // line 45
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["host"] ?? null), "html", null, true);
        yield "\"
          >
        </td>
      </tr>
      <tr>
        <th>
          <label class=\"form-label\" for=\"port\">";
        // line 51
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("setup.wizard.database.port"), "html", null, true);
        yield "</label>
        </th>
        <td>
          <input
            class=\"form-input\"
            name=\"port\"
            type=\"text\"
            id=\"port\"
            size=\"25\"
            value=\"";
        // line 60
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["port"] ?? null), "html", null, true);
        yield "\"
          >
        </td>
      </tr>
      <tr>
        <th>
          <label class=\"form-label\" for=\"username\">";
        // line 66
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("setup.wizard.database.username"), "html", null, true);
        yield "</label>
        </th>
        <td>
          <input
            class=\"form-input\"
            name=\"username\"
            type=\"text\"
            id=\"username\"
            size=\"25\"
            value=\"";
        // line 75
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["username"] ?? null), "html", null, true);
        yield "\"
          >
        </td>
      </tr>
      <tr>
        <th>
          <label class=\"form-label\" for=\"password\">";
        // line 81
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("setup.wizard.database.password"), "html", null, true);
        yield "</label>
        </th>
        <td>
          <input
            class=\"form-input\"
            type=\"password\"
            name=\"password\"
            id=\"password\"
            value=\"";
        // line 89
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["password"] ?? null), "html", null, true);
        yield "\"
          >
        </td>
      </tr>
      <tr>
        <th>
          <label class=\"form-label\" for=\"db\">";
        // line 95
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("setup.wizard.database.db"), "html", null, true);
        yield "</label>
        </th>
        <td>
          <input
            class=\"form-input\"
            name=\"db\"
            type=\"text\"
            id=\"db\"
            size=\"25\"
            value=\"";
        // line 104
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["database"] ?? null), "html", null, true);
        yield "\"
          >
        </td>
      </tr>
      <tr>
        <th></th>
        <td><p><small>";
        // line 110
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("setup.wizard.database.db-notice"), "html", null, true);
        yield "</small></p></td>
      </tr>
      <tr>
        <th>
          <label class=\"form-label\" for=\"prefix\">";
        // line 114
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("setup.wizard.database.prefix"), "html", null, true);
        yield "</label>
        </th>
        <td>
          <input
            class=\"form-input\"
            name=\"prefix\"
            type=\"text\"
            id=\"prefix\"
            size=\"25\"
            value=\"";
        // line 123
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["prefix"] ?? null), "html", null, true);
        yield "\"
          >
        </td>
      </tr>
      <tr>
        <th></th>
        <td><p><small>";
        // line 129
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("setup.wizard.database.prefix-notice"), "html", null, true);
        yield "</small></p></td>
      </tr>
    </table>

    ";
        // line 133
        if (TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["errors"] ?? null), "any", [], "any", false, false, false, 133)) {
            // line 134
            yield "      <div class=\"toast toast-error\" role=\"alert\">
        <ul>
          ";
            // line 136
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["errors"] ?? null), "all", [], "any", false, false, false, 136));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 137
                yield "            <li>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["error"], "html", null, true);
                yield "</li>
          ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['error'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 139
            yield "        </ul>
      </div>
    ";
        }
        // line 142
        yield "
    <p class=\"step\">
      <input
        type=\"submit\"
        name=\"submit\"
        id=\"submit\"
        class=\"btn btn-primary\"
        value=\"";
        // line 149
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("setup.wizard.welcome.button"), "html", null, true);
        yield "\"
      >
    </p>
</form>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/setup/wizard/database.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  286 => 149,  277 => 142,  272 => 139,  263 => 137,  259 => 136,  255 => 134,  253 => 133,  246 => 129,  237 => 123,  225 => 114,  218 => 110,  209 => 104,  197 => 95,  188 => 89,  177 => 81,  168 => 75,  156 => 66,  147 => 60,  135 => 51,  126 => 45,  114 => 36,  92 => 17,  85 => 13,  79 => 10,  71 => 6,  64 => 5,  53 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/setup/wizard/database.twig", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/setup/wizard/database.twig");
    }
}
