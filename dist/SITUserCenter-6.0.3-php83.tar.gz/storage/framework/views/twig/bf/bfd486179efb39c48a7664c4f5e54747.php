<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\Users\Administrator\Desktop\blessingskin\SITUserCenter-clean\resources\views/auth/verify.twig */
class __TwigTemplate_fa7a5fe85a9b28e3bbee33922d606826 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "auth.base";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $context = TwigBridge\Node\EventNode::triggerLaravelEvents($this->getTemplateName(), $context);
        $this->parent = $this->loadTemplate("auth.base", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/auth/verify.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("auth.verify.title"), "html", null, true);
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "  <p class=\"login-box-msg\">
    ";
        // line 7
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("auth.bind.message"), "html", null, true);
        yield "
  </p>
  <form method=\"post\">
    ";
        // line 10
        yield csrf_field();
        yield "
    <div class=\"input-group mb-3\">
      <input type=\"email\" name=\"email\" class=\"form-control\" placeholder=";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("auth.email"), "html", null, true);
        yield " required>
      <div class=\"input-group-append\">
        <div class=\"input-group-text\">
          <i class=\"fas fa-envelope\"></i>
        </div>
      </div>
    </div>
    ";
        // line 19
        if (TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["errors"] ?? null), "any", [], "any", false, false, false, 19)) {
            // line 20
            yield "      <div class=\"alert alert-danger\">
        <i class=\"icon fas fa-exclamation-triangle\"></i>
        ";
            // line 22
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(TwigBridge\Node\GetAttrNode::attribute($this->env, $this->source, ($context["errors"] ?? null), "first", [], "any", false, false, false, 22), "html", null, true);
            yield "
      </div>
    ";
        } elseif ($this->env->getFunction('session_has')->getCallable()("errorMessage")) {
            // line 25
            yield "      <div class=\"alert alert-danger\">
        <i class=\"icon fas fa-exclamation-triangle\"></i>
        ";
            // line 27
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('session_pull')->getCallable()("errorMessage"), "html", null, true);
            yield "
      </div>
    ";
        }
        // line 30
        yield "    <button type=\"submit\" class=\"btn btn-primary btn-block\">
      ";
        // line 31
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getFunction('trans')->getCallable()("general.submit"), "html", null, true);
        yield "
    </button>
  </form>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/auth/verify.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  120 => 31,  117 => 30,  111 => 27,  107 => 25,  101 => 22,  97 => 20,  95 => 19,  85 => 12,  80 => 10,  74 => 7,  71 => 6,  64 => 5,  53 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/auth/verify.twig", "C:\\Users\\Administrator\\Desktop\\blessingskin\\SITUserCenter-clean\\resources\\views/auth/verify.twig");
    }
}
