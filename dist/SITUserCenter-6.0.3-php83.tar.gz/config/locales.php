<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Configuration for i18n
    |--------------------------------------------------------------------------
    |
    | Available Languages
    |
    */
    'zh_CN' => [
        'name' => '中文 (简体)',
        'short_name' => 'zh-CN',
    ],
    'zh_HANS_CN' => [
        'alias' => 'zh_CN',
    ],
    'en' => [
        'name' => 'English',
        'short_name' => 'en',
    ],
    'en_US' => [
        'alias' => 'en',
    ],
];
